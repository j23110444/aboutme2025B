def mis2a():
    print("資管二A")

def mis2b():
    print("資管二B")

mis2b()
mis2a()