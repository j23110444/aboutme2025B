from mis import mis2a,mis2b

mis2a()
mis2b()
