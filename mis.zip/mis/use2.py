import mis as m

m.mis2a()
m.mis2b()
