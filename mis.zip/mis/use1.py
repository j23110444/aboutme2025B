import mis.py

mis.mis2a()
mis.mis2b()
